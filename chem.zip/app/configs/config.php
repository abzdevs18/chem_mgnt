
			<?php
			// DB params

			define('DB_HOST', 'localhost');
			define('DB_USER', 'root');
			define('DB_PASS', 'D3b1an!?');
			define('DB_NAME', 'ch_mgnt');

			//APP ROOT
			define('APP_ROOT', dirname(dirname(__FILE__)));

			//URL ROOT
			define('URL_ROOT', 'https://192.168.0.28/chem');
			// define('URL_ROOT', 'https://chemlab.cf');

			//SITE NAME
			define('SITE_NAME', 'Help Agency');

			//SALT
			define('SECURE_SALT', 'k<UL?Gxr%6bTv[IX5h>s)vaEurK]4Sn');

			?>