<?php
echo "string";