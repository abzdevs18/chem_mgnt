<?php

require_once '../app/init.php';

/*Initialization*/

$init = new Core();